/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from "motion/react";
import { 
  Github, 
  Linkedin, 
  Twitter, 
  Mail, 
  Phone, 
  MapPin, 
  ExternalLink, 
  GraduationCap, 
  Briefcase, 
  Award, 
  Code, 
  ChevronRight,
  Menu,
  X,
  Globe,
  User,
  Download,
  Star,
  Flag,
  Trophy,
  Monitor,
  Users,
  MessageSquare,
  Layout,
  Sun,
  Moon,
  Folder
} from "lucide-react";
import React, { useState, useEffect } from "react";

// --- Data from CV ---
const CV_DATA = {
  name: "Sajin Ahmmed Joy",
  titles: ["Student", "Entrepreneur", "Organizer"],
  summary: "A motivated student with a strong passion for continuous learning and student engagement, aspiring to contribute positively to society through organizational activities.",
  contact: {
    phone: "01925-909461",
    email: "sajinahmmedjoy@gmail.com",
    address: "Airport Road, Jashore - 7400"
  },
  skills: [
    { name: "Student Counseling", category: "Communication", level: "Expert", icon: <Users size={18} /> },
    { name: "Leadership", category: "Leadership", level: "Expert", icon: <Trophy size={18} /> },
    { name: "Event Management", category: "Leadership", level: "Expert", icon: <Layout size={18} /> },
    { name: "Basic Computer Skills", category: "Tech", level: "Expert", icon: <Monitor size={18} /> },
    { name: "Time Management", category: "Management", level: "Expert", icon: <MessageSquare size={18} /> },
    { name: "Networking", category: "Communication", level: "Advanced", icon: <Globe size={18} /> },
    { name: "Market Research", category: "Tech", level: "Advanced", icon: <Monitor size={18} /> },
    { name: "Team Collaboration", category: "Leadership", level: "Expert", icon: <Users size={18} /> },
    { name: "Debate & Public Speaking", category: "Communication", level: "Expert", icon: <MessageSquare size={18} /> },
    { name: "Project Presentation", category: "Communication", level: "Expert", icon: <Monitor size={18} /> },
    { name: "Science Project Development", category: "Tech", level: "Advanced", icon: <Monitor size={18} /> },
    { name: "Anchoring / Event Hosting", category: "Communication", level: "Expert", icon: <Users size={18} /> },
    { name: "Human Resource Management", category: "Leadership", level: "Advanced", icon: <Users size={18} /> },
    { name: "Sponsorship Management", category: "Leadership", level: "Advanced", icon: <Layout size={18} /> },
    { name: "Report Writing", category: "Communication", level: "Advanced", icon: <MessageSquare size={18} /> },
    { name: "Professional Poster Design", category: "Design", level: "Advanced", icon: <Layout size={18} /> }
  ],
  education: [
    {
      period: "2025-Present",
      institution: "Daffodil International University",
      degree: "Bachelor in Innovation & Entrepreneurship",
      stream: "Faculty of Business & Entrepreneurship",
      description: "Focusing on entrepreneurial strategies and innovation management."
    },
    {
      period: "2023-2024",
      institution: "Cantonment College Jashore",
      degree: "Higher Secondary Certificate (HSC)",
      stream: "Science | GPA: 4.08",
      description: "Participated in science competitions and cultural events."
    },
    {
      period: "2021-2022",
      institution: "Rupdia Welfare Academy - Jashore",
      degree: "Secondary School Certificate (SSC)",
      stream: "Science | GPA: 5.00 (Golden)",
      description: "Achieved Academic Excellence award and recognized as Top of Batch."
    }
  ],
  experience: [
    {
      period: "2020-2026",
      role: "President",
      organization: "J.C.B Science Club",
      description: "Affiliated with the Ministry of Science and Technology. Organized national-level Science Fairs and research camps for rural children.",
      link: "https://www.facebook.com/share/1EGEZP7yj6/"
    },
    {
      period: "2024-2025",
      role: "Stakeholder Member",
      organization: "NMST",
      description: "Ministry of Science and Technology. Focused on improving accessibility for students from diverse backgrounds through innovative teaching materials.",
      link: "https://nmst.gov.bd/"
    }
  ],
  achievements: [
    {
      title: "Best Student 2024",
      description: "Honored as 'Best Student' of Khulna Division for outstanding academic and organizational performance.",
      icon: <Star size={32} />
    }
  ],
  languages: ["English", "Bangla"]
};

// --- Components ---

const Navbar = ({ theme, toggleTheme }: { theme: string, toggleTheme: () => void }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = ["About", "Education", "Experience", "Skills", "Projects", "Achievements", "Contact"];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? "bg-brand-dark/80 backdrop-blur-md py-4 border-b border-white/5" : "bg-transparent py-6"}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-xl font-display font-bold tracking-tighter text-brand-accent"
        >
          SAJIN.JOY
        </motion.div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} className="nav-link">
              {item}
            </a>
          ))}
          
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-xl bg-brand-navy border border-brand-border text-brand-accent hover:bg-brand-accent/10 transition-colors"
            aria-label="Toggle Theme"
          >
            {theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>

        {/* Mobile Toggle */}
        <div className="flex items-center gap-4 md:hidden">
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-xl bg-brand-navy border border-brand-border text-brand-accent"
            aria-label="Toggle Theme"
          >
            {theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button className="text-[var(--text-primary)]" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-brand-navy border-b border-white/5 overflow-hidden"
          >
            <div className="flex flex-col p-6 gap-4">
              {navItems.map((item) => (
                <a 
                  key={item} 
                  href={`#${item.toLowerCase()}`} 
                  className="text-base font-medium text-[var(--text-secondary)]"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const GithubProjects = () => {
  const [repos, setRepos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const username = "parthoew";

  useEffect(() => {
    fetch(`https://api.github.com/users/${username}/repos?sort=updated&per_page=6`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setRepos(data);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error("Error fetching repos:", err);
        setLoading(false);
      });
  }, []);

  return (
    <section id="projects" className="py-20">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeading title="GitHub Projects" icon={<Github size={24} />} />
        
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="glass-card p-8 h-48 animate-pulse bg-brand-navy/50"></div>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {repos.map((repo, i) => (
              <motion.a
                key={repo.id}
                href={repo.html_url}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5 }}
                className="glass-card p-8 flex flex-col h-full hover:border-brand-accent/30 transition-all duration-300 group"
              >
                <div className="flex justify-between items-start mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-brand-accent/10 flex items-center justify-center text-brand-accent group-hover:scale-110 transition-transform duration-500">
                    <Folder size={24} />
                  </div>
                  <div className="flex gap-2">
                    {repo.stargazers_count > 0 && (
                      <div className="flex items-center gap-1 text-xs font-bold text-yellow-500">
                        <Star size={12} fill="currentColor" /> {repo.stargazers_count}
                      </div>
                    )}
                    <ExternalLink size={16} className="text-[var(--text-muted)] group-hover:text-brand-accent transition-colors" />
                  </div>
                </div>
                
                <h3 className="text-xl font-bold mb-2 group-hover:text-brand-accent transition-colors truncate">
                  {repo.name}
                </h3>
                
                <p className="text-[var(--text-secondary)] text-sm leading-relaxed mb-6 line-clamp-2 flex-1">
                  {repo.description || "No description provided for this project."}
                </p>
                
                <div className="flex items-center justify-between pt-4 border-t border-brand-border/50 mt-auto">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-brand-accent"></div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">
                      {repo.language || "Unknown"}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">
                    {new Date(repo.updated_at).toLocaleDateString()}
                  </span>
                </div>
              </motion.a>
            ))}
          </div>
        )}
        
        <div className="mt-12 text-center">
          <a 
            href={`https://github.com/${username}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-brand-accent font-bold hover:gap-3 transition-all"
          >
            View All Repositories <ChevronRight size={16} />
          </a>
        </div>
      </div>
    </section>
  );
};

const SectionHeading = ({ title, icon }: { title: string, icon: React.ReactNode }) => (
  <div className="flex items-center gap-4 mb-12">
    <div className="section-icon mb-0">
      {icon}
    </div>
    <h2 className="text-3xl md:text-4xl font-display font-bold">
      {title}
    </h2>
  </div>
);

export default function App() {
  const [skillFilter, setSkillFilter] = useState("All");
  const [theme, setTheme] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("theme") || "dark";
    }
    return "dark";
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === "dark" ? "light" : "dark");

  const categories = ["All", "Leadership", "Communication", "Tech", "Design", "Management"];

  const filteredSkills = skillFilter === "All" 
    ? CV_DATA.skills 
    : CV_DATA.skills.filter(s => s.category === skillFilter);

  return (
    <div className="min-h-screen selection:bg-brand-accent/30 bg-brand-dark relative">
      <Navbar theme={theme} toggleTheme={toggleTheme} />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-block px-5 py-2 rounded-full bg-brand-accent/10 border border-brand-accent/20 text-brand-accent text-xs font-bold uppercase tracking-widest mb-8"
          >
            Portfolio
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-display font-bold leading-tight mb-8"
          >
            Hi, I'm <span className="text-brand-accent">{CV_DATA.name}</span>
          </motion.h1 >

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-[var(--text-secondary)] text-lg md:text-xl max-w-3xl mx-auto mb-12 leading-relaxed"
          >
            {CV_DATA.titles.join(' | ')}
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-wrap justify-center gap-4 mb-20"
          >
            <a 
              href="https://drive.google.com/file/d/10sornDjaTn-dMlkOawOZnjn3M2slB_05/view?usp=drivesdk" 
              target="_blank"
              rel="noopener noreferrer"
              className="bg-brand-accent text-white px-6 py-3 rounded-xl font-bold shadow-xl shadow-brand-accent/20 flex items-center gap-2 hover:bg-brand-accent/90 transition-colors text-sm"
            >
              <Download size={18} /> Download CV
            </a>
            <a 
              href="#contact"
              className="bg-brand-navy border border-brand-border text-white px-6 py-3 rounded-xl font-bold hover:bg-brand-navy/80 transition-colors text-sm"
            >
              Contact Me
            </a>
          </motion.div>

          <div className="relative max-w-xs mx-auto mt-12">
            {/* Background Design - High Visibility */}
            {/* Large Soft Glow */}
            <div className="absolute -inset-24 bg-brand-accent/20 rounded-full blur-[100px] -z-10"></div>
            
            {/* Vibrant Blobs */}
            <div className="absolute -top-16 -left-16 w-48 h-48 bg-brand-accent/30 rounded-full blur-3xl -z-10 animate-pulse"></div>
            <div className="absolute -bottom-16 -right-16 w-56 h-56 bg-brand-accent/40 rounded-full blur-3xl -z-10"></div>
            
            {/* Decorative Rings */}
            <div className="absolute -inset-10 border border-brand-accent/20 rounded-[70px] -z-10"></div>
            <div className="absolute -inset-20 border border-brand-accent/10 rounded-[80px] -z-10"></div>
            
            {/* The Image Container */}
            <div className="rounded-[60px] overflow-hidden border border-brand-accent/30 shadow-[0_0_50px_rgba(59,130,246,0.2)] relative z-10 bg-black">
              <img 
                src="https://image2url.com/r2/default/images/1774884619779-aca447ed-2f00-455a-b0d4-aec54a4c4aa1.jpg" 
                alt="Sajin Ahmmed Joy" 
                className="w-full h-auto block"
                referrerPolicy="no-referrer"
              />
            </div>
            
            {/* Floating Accents */}
            <div className="absolute -top-4 -right-4 w-12 h-12 bg-brand-accent rounded-2xl rotate-12 -z-10 blur-sm opacity-50"></div>
            <div className="absolute -bottom-4 -left-4 w-10 h-10 bg-blue-400 rounded-full -z-10 blur-sm opacity-50"></div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <SectionHeading title="About Me" icon={<User size={24} />} />
              <p className="text-[var(--text-secondary)] text-lg leading-relaxed mb-12">
                {CV_DATA.summary} Currently an aspiring Innovation & Entrepreneurship student, I focus on improving accessibility for students from diverse backgrounds through innovative teaching materials and hands-on learning.
              </p>
              
              <div className="grid gap-4">
                <a href={`mailto:${CV_DATA.contact.email}`} className="glass-card p-6 flex items-center gap-6 hover:bg-brand-accent/5 transition-colors">
                  <div className="w-12 h-12 rounded-xl bg-brand-accent/10 flex items-center justify-center text-brand-accent">
                    <Mail size={20} />
                  </div>
                  <div>
                    <div className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-widest mb-1">Email</div>
                    <div className="text-sm font-medium">{CV_DATA.contact.email}</div>
                  </div>
                </a>
                <a href={`tel:${CV_DATA.contact.phone}`} className="glass-card p-6 flex items-center gap-6 hover:bg-brand-accent/5 transition-colors">
                  <div className="w-12 h-12 rounded-xl bg-brand-accent/10 flex items-center justify-center text-brand-accent">
                    <Phone size={20} />
                  </div>
                  <div>
                    <div className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-widest mb-1">Phone</div>
                    <div className="text-sm font-medium">{CV_DATA.contact.phone}</div>
                  </div>
                </a>
                <div className="glass-card p-6 flex items-center gap-6">
                  <div className="w-12 h-12 rounded-xl bg-brand-accent/10 flex items-center justify-center text-brand-accent">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <div className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-widest mb-1">Location</div>
                    <div className="text-sm font-medium">{CV_DATA.contact.address}</div>
                  </div>
                </div>
                <div className="glass-card p-6 flex items-center gap-6">
                  <div className="w-12 h-12 rounded-xl bg-brand-accent/10 flex items-center justify-center text-brand-accent">
                    <Globe size={20} />
                  </div>
                  <div>
                    <div className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-widest mb-1">Languages</div>
                    <div className="text-sm font-medium">{CV_DATA.languages.join(', ')}</div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="glass-card p-10"
            >
              <h3 className="text-lg font-bold mb-8">Quick Highlights</h3>
              <div className="space-y-8">
                <div className="flex gap-6">
                  <div className="text-brand-accent"><Trophy size={24} /></div>
                  <div>
                    <div className="font-bold mb-1">Best Student 2024</div>
                    <div className="text-sm text-[var(--text-secondary)]">Khulna Division</div>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="text-brand-accent"><Briefcase size={24} /></div>
                  <div>
                    <div className="font-bold mb-1">President</div>
                    <div className="text-sm text-[var(--text-secondary)]">J.C.B Science Club</div>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="text-brand-accent"><GraduationCap size={24} /></div>
                  <div>
                    <div className="font-bold mb-1">Golden GPA 5.00</div>
                    <div className="text-sm text-[var(--text-secondary)]">SSC Excellence</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <SectionHeading title="Education" icon={<GraduationCap size={24} />} />
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CV_DATA.education.map((edu, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card p-8 flex flex-col h-full hover:border-brand-accent/30 transition-all duration-300 group"
              >
                <div className="w-12 h-12 rounded-2xl bg-brand-accent/10 flex items-center justify-center text-brand-accent mb-6 group-hover:scale-110 transition-transform duration-500">
                  <GraduationCap size={24} />
                </div>
                <div className="badge mb-4 w-fit">{edu.period}</div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-brand-accent transition-colors">{edu.institution}</h3>
                <h4 className="text-base font-semibold text-[var(--text-primary)] mb-4">{edu.degree}</h4>
                <div className="mt-auto pt-4 border-t border-brand-border/50">
                  <p className="text-[var(--text-secondary)] text-sm leading-relaxed">
                    <span className="font-bold text-brand-accent block mb-1">{edu.stream}</span>
                    {edu.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <SectionHeading title="Professional Experience" icon={<Briefcase size={24} />} />
          <div className="grid md:grid-cols-2 gap-8">
            {CV_DATA.experience.map((exp, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="glass-card p-10 group"
              >
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="text-2xl font-bold mb-2 group-hover:text-brand-accent transition-colors">{exp.role}</h3>
                    <div className="text-brand-accent text-base font-semibold">{exp.organization}</div>
                  </div>
                  <div className="badge bg-brand-navy border-brand-border">{exp.period}</div>
                </div>
                <p className="text-[var(--text-secondary)] text-sm leading-relaxed mb-8">
                  {exp.description}
                </p>
                <a 
                  href={exp.link} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center gap-2 text-brand-accent text-sm font-bold hover:gap-3 transition-all"
                >
                  View Website <ExternalLink size={14} />
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <GithubProjects />

      {/* Skills Section */}
      <section id="skills" className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <SectionHeading title="Skills & Expertise" icon={<Code size={24} />} />
          
          <div className="flex flex-wrap gap-3 mb-12">
            {categories.map((cat) => (
              <button 
                key={cat}
                onClick={() => setSkillFilter(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${skillFilter === cat ? "bg-brand-accent text-white shadow-lg shadow-brand-accent/20" : "bg-brand-navy border border-brand-border text-gray-300 hover:border-brand-accent/50"}`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence mode="popLayout">
              {filteredSkills.map((skill, i) => (
                <motion.div 
                  key={skill.name}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="glass-card p-4 flex items-center gap-4 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-brand-accent/10 flex items-center justify-center text-brand-accent group-hover:bg-brand-accent group-hover:text-white transition-colors shrink-0">
                    {skill.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-end mb-1.5">
                      <div className="truncate">
                        <div className="text-sm font-bold mb-0.5 truncate">{skill.name}</div>
                        <div className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-widest truncate">{skill.category}</div>
                      </div>
                      <div className="flex flex-col items-end shrink-0 ml-2">
                        <div className="text-[10px] text-brand-accent font-bold uppercase tracking-widest mb-1">{skill.level}</div>
                        <div className="flex gap-0.5">
                          {[...Array(5)].map((_, index) => (
                            <div 
                              key={index}
                              className={`w-1.5 h-1.5 rounded-full ${
                                index < (skill.level === "Expert" ? 5 : 4) 
                                  ? "bg-brand-accent shadow-[0_0_8px_rgba(59,130,246,0.5)]" 
                                  : "bg-brand-navy border border-brand-border"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="h-1.5 w-full bg-brand-navy rounded-full overflow-hidden border border-brand-border/50">
                      <motion.div 
                        initial={{ width: 0 }}
                        whileInView={{ width: skill.level === "Expert" ? "100%" : "80%" }}
                        transition={{ duration: 1, ease: "easeOut" }}
                        className="h-full bg-gradient-to-r from-blue-600 to-blue-400 relative"
                      >
                        <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(255,255,255,0.2)_50%,transparent_100%)] animate-[shimmer_2s_infinite]"></div>
                      </motion.div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section id="achievements" className="py-20 relative overflow-hidden">
        <div className="max-w-4xl mx-auto px-6">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center gap-6 mb-16 justify-center"
          >
            <div className="w-16 h-16 rounded-2xl bg-brand-accent/10 flex items-center justify-center text-brand-accent border border-brand-accent/20">
              <Trophy size={32} />
            </div>
            <h2 className="text-4xl md:text-5xl font-display font-bold">Achievements</h2>
          </motion.div>

          <div className="space-y-8">
            {/* Large Cards */}
            {[
              { title: "Best Student 2024", desc: "Honored as 'Best Student' of Khulna Division for outstanding academic and organizational performance.", icon: <Star size={28} /> },
              { title: "International Awards", value: "2", desc: "Recognized for excellence at the global stage in innovation and science.", icon: <Globe size={28} /> },
              { title: "National Awards", value: "8", desc: "Multiple prestigious national awards for academic and leadership excellence.", icon: <Trophy size={28} /> },
            ].map((ach, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover="hover"
                className="glass-card p-6 flex flex-col items-center text-center group hover:border-brand-accent/30 transition-all duration-500"
              >
                <motion.div 
                  variants={{
                    hover: { 
                      rotate: [0, -10, 10, -10, 0],
                      scale: 1.1,
                      filter: "drop-shadow(0 0 8px rgba(59, 130, 246, 0.5))"
                    }
                  }}
                  transition={{ duration: 0.5 }}
                  className="w-16 h-16 rounded-2xl bg-brand-accent/10 flex items-center justify-center text-brand-accent mb-6 border border-brand-accent/10 transition-transform duration-500"
                >
                  {ach.icon}
                </motion.div>
                <h3 className="text-xl font-display font-bold mb-3">
                  {ach.value && <span className="text-brand-accent mr-2">{ach.value}</span>}
                  {ach.title}
                </h3>
                <p className="text-[var(--text-secondary)] text-xs leading-relaxed max-w-sm mx-auto">
                  {ach.desc}
                </p>
              </motion.div>
            ))}

            {/* Small Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { label: "Divisional", value: "30+", icon: <Award size={20} /> },
                { label: "District", value: "100+", icon: <Star size={20} /> },
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  whileHover="hover"
                  className="glass-card p-5 flex items-center gap-4 hover:border-brand-accent/30 transition-all duration-300"
                >
                <motion.div 
                  variants={{
                    hover: { scale: 1.2, rotate: 15 }
                  }}
                  transition={{ type: "spring", stiffness: 300 }}
                  className="text-brand-accent"
                >
                  {stat.icon}
                </motion.div>
                  <div>
                    <div className="text-lg font-bold">{stat.value}</div>
                    <div className="text-[10px] text-[var(--text-muted)] uppercase tracking-widest font-bold">
                      {stat.label}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="max-w-3xl">
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-8 leading-tight">
              Let's connect and build something great.
            </h2>
            <p className="text-[var(--text-secondary)] text-lg mb-12">
              I'm always open to discussing new projects, creative ideas or opportunities to be part of your visions.
            </p>
            
            <div className="grid md:grid-cols-2 gap-6 mb-12">
              <a href={`mailto:${CV_DATA.contact.email}`} className="glass-card p-8 flex items-center gap-6 hover:bg-brand-accent/5 transition-colors">
                <div className="w-14 h-14 rounded-2xl bg-brand-navy border border-brand-border flex items-center justify-center text-[var(--text-secondary)]">
                  <Mail size={24} />
                </div>
                <div>
                  <div className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-widest mb-1">Email Me</div>
                  <div className="text-xs font-medium">{CV_DATA.contact.email}</div>
                </div>
              </a>
              <a href={`tel:${CV_DATA.contact.phone}`} className="glass-card p-8 flex items-center gap-6 hover:bg-brand-accent/5 transition-colors">
                <div className="w-14 h-14 rounded-2xl bg-brand-navy border border-brand-border flex items-center justify-center text-[var(--text-secondary)]">
                  <Phone size={24} />
                </div>
                <div>
                  <div className="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-widest mb-1">Call Me</div>
                  <div className="text-xs font-medium">{CV_DATA.contact.phone}</div>
                </div>
              </a>
            </div>

            <div className="flex gap-4">
              {[
                { icon: <Linkedin size={20} />, link: "#" },
                { icon: <Twitter size={20} />, link: "#" },
                { icon: <Github size={20} />, link: "#" }
              ].map((social, i) => (
                <motion.a 
                  key={i}
                  href={social.link}
                  whileHover={{ y: -5, backgroundColor: "rgba(59, 130, 246, 0.1)", color: "#3b82f6" }}
                  className="w-14 h-14 rounded-2xl glass-card flex items-center justify-center text-[var(--text-secondary)] transition-all"
                >
                  {social.icon}
                </motion.a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-xl font-display font-bold tracking-tighter text-brand-accent">
            SAJIN.
          </div>
          <p className="text-[var(--text-muted)] text-sm">
            © {new Date().getFullYear()} Sajin Ahmmed Joy. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
